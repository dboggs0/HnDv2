﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class btnPlayBehavior : MonoBehaviour
{
    public void PlayGame()
    {
        Debug.Log("Go play");
    }
}
